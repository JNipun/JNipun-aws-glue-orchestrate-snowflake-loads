"""
__author__ = "Nipun Jain"
__credits__ = ["Nipun Jain, Nagarro"]
__version__ = "0.0.1"
__maintainer__ = "Nipun Jain"
__email__ = "nipun.jain@coxautoinc.com"
__status__ = "Production"

This script will call aws secret manager service and return values from given secret key.
    Example: $ python3 secret_manager.py
"""

# Use this code snippet in your app.
import json
import io
import datetime
import boto3
from .string_io_logger import get_string_io_logger
from botocore.exceptions import ClientError


# noinspection PyGlobalUndefined
def get_secret(secret_name=None):
    """
    :param secret_name: secret key name
    :return:
    """
    # noinspection PyGlobalUndefined
    global secret
    region_name = "us-east-1"
    cur_date = datetime.datetime.now()

    # create string i/o object as string buffer
    log_stringio_obj = io.StringIO()

    # create stream log handler with string i/o buffer
    logger = get_string_io_logger(log_stringio_obj, logger_name=__name__)

    logger.info("Script Execution started at:- %s", cur_date)
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=region_name)

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        logger.info("Connecting to aws secret manager")
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        logger.info("Response collected from aws secret manager for given secret_name")
    except ClientError as error:
        logger.error(
            "Response collection from aws secret manager for "
            "given secret_name failed due to below error\n%s", error
        )
    else:
        secret_logs = log_stringio_obj.getvalue()
        # Decrypts secret using the associated KMS key.
        # Depending on whether the secret is a string or binary
        # one of these fields will be populated.
        if "SecretString" in get_secret_value_response:
            secret = get_secret_value_response["SecretString"]
            logger.info("Secret values have been collected successfully")

    # Your code goes here.
    return json.loads(secret), secret_logs  # returns the secret as dictionary
