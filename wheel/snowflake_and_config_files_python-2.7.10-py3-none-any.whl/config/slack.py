"""
__author__ = "Nipun Jain"
__credits__ = ["Nipun Jain, Nagarro"]
__version__ = "0.0.1"
__maintainer__ = "Nipun Jain"
__email__ = "nipun.jain@coxautoinc.com"
__status__ = "Production"

This script will call snowflake procedure and send notification over slack in case of failure.
    Example: $ python3 sns.py
"""

import os

from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


class SlackMessage:
    """
    Slack API Connection init class which will inherit slack class
    """
    def __init__(
        self, text, block_text=None, attachment=None, threads=None, destination=None
    ):
        self.text = text
        self.block_text = block_text
        self.attachment = attachment
        self.threads = threads
        self.destination = destination


class Slack:
    """
    Slack class method
    """
    client = None

    def __init__(self, slack_token, verify_token):
        self.slack_token = slack_token
        self.verify_token = verify_token

    def get_client(self):
        """
        Method to get slack client after passing slack and verify token
        """
        if Slack.client is not None:
            return Slack.client

        try:
            Slack.client = WebClient(token=self.slack_token)
            return Slack.client
        except Exception as error:
            print(error)

    def post_slack_messages(self, messages, channel_id):
        """
        Method to post more than one message on Slack
        Args:
        message: provide message content
        channel_id: provide slack channel name
        Returns: Publishes a message to a topic
        """
        for msg in messages:
            if msg is not None:
                self.post_slack_message(msg, channel_id)

    def post_slack_message(self, message, channel_id):
        """
        Method to post message on slack channel
        """
        print("INFO: post_slack_message::slack")

        try:
            main_response = self.get_client().chat_postMessage(
                channel=channel_id
                if message.destination is None
                else message.destination,
                text=message.text,
                blocks=message.block_text,
                link_names=True,
            )

            # Add any messages to the thread
            if message.threads:
                for thread in message.threads:
                    self.get_client().chat_postMessage(
                        channel=channel_id
                        if message.destination is None
                        else message.destination,
                        text=thread.text,
                        blocks=thread.block_text,
                        link_names=True,
                        thread_ts=main_response["ts"],
                    )

            # Attach a file in the thread of the original message
            if message.attachment and os.path.isfile(message.attachment["filePath"]):
                self.get_client().files_upload(
                    channels=channel_id
                    if message.destination is None
                    else message.destination,
                    file=message.attachment["filePath"],
                    title=message.attachment["title"],
                    filetype=message.attachment["fileType"],
                    thread_ts=main_response["ts"],
                )

        except SlackApiError as error:
            print(
                f"ERROR: post_slack_message::Got an error: {0}".format(
                    {error.response["error"]}
                )
            )
