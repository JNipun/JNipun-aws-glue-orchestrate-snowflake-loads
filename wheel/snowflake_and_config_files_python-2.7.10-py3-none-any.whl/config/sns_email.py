"""
__author__ = "Nipun Jain"
__credits__ = ["Nipun Jain, Nagarro"]
__version__ = "0.0.1"
__maintainer__ = "Nipun Jain"
__email__ = "nipun.jain@coxautoinc.com"
__status__ = "Production"

This script will call aws sns service and send emails.
    Example: $ python3 sns_email.py
"""

import io
import boto3
from botocore.exceptions import ClientError
from .string_io_logger import get_string_io_logger

AWS_REGION = "us-east-1"
sns_client = boto3.client("sns", region_name=AWS_REGION)

# create string i/o object as string buffer
log_stringio_obj = io.StringIO()

# create stream log handler with string i/o buffer
logger = get_string_io_logger(log_stringio_obj, logger_name=__name__)


def list_topics():
    """
    Lists all SNS notification topics using paginator.
    """
    try:
        logger.info("Connecting to aws sns services to list topics")
        paginator = sns_client.get_paginator("list_topics")

        # creating a PageIterator from the paginator
        page_iterator = paginator.paginate().build_full_result()

        topics_list = []

        # loop through each page from page_iterator
        for page in page_iterator["Topics"]:
            topics_list.append(page["TopicArn"])
    except ClientError as error:
        logger.error("Could not list SNS topics. Below is the error %s", error)
        raise error
    else:
        logger.info("Topics list collected from AWS SNS service successfully")
        return topics_list


def publish_message(message=None, subject=None):
    """
    Args:
        message: provide message content
        subject: provide subject line

    Returns: Publishes a message to a topic
    """
    try:
        topics = list_topics()
        recon_sns = []
        responses = []

        # loop to get sns topics for recon application only
        for topic in topics:
            if "dera-txn-recon" in topic:
                recon_sns.append(topic)
        for i in recon_sns:
            response = sns_client.publish(
                TopicArn=i,
                Message=message,
                Subject=subject,
            )["MessageId"]
            responses.append(response)
            logger.info(
                "Respective stake holders have been notified through sns topic-%s",
                str(i[39:])
            )
    except ClientError as error:
        logger.error("Could not publish message to the given topic.%s", error)
    else:
        sns_logs = log_stringio_obj.getvalue()
        return responses, sns_logs
