"""
__author__ = "Nipun Jain"
__credits__ = ["Nipun Jain, Nagarro"]
__version__ = "0.0.1"
__maintainer__ = "Nipun Jain"
__email__ = "nipun.jain@coxautoinc.com"
__status__ = "Production"

This script will call aws parameter service and return values from given key.
    Example: $ python3 ssm_params.py
"""

# Use this code snippet in your app.

import io
import boto3
from botocore.exceptions import ClientError
from .string_io_logger import get_string_io_logger


def get_param(param_name: object = None) -> object:
    """
    :param param_name: parameter key name
    :return:
    """
    if param_name is None:
        param_name = []
    region_name = "us-east-1"
    final_out = {}

    # create string i/o object as string buffer
    log_stringio_obj = io.StringIO()

    # create stream log handler with string i/o buffer
    logger = get_string_io_logger(log_stringio_obj, logger_name=__name__)

    # Create an AWS SSM Manager client
    session = boto3.session.Session()
    client = session.client(service_name="ssm", region_name=region_name)

    # In this sample we only handle the specific exceptions for the 'get_parameter' API.
    # We rethrow the exception by default.
    try:
        logger.info("Connecting to aws ssm service")
        get_param_value_response = client.get_parameters(
            Names=param_name, WithDecryption=True
        )
        param_out = get_param_value_response["Parameters"]

        # loop to get parameter name and it's values only and appending into a final dict
        for i in param_out:
            key = i["Name"].replace("/", "")
            final_out[key] = i["Value"]
        logger.info("Response collected from aws ssm manager for given param_name")
    except ClientError as error:
        logger.error(
            "Response collection from aws ssm for "
            "given param_name failed due to below error\n%s", error
        )
    else:
        params_logs = log_stringio_obj.getvalue()
        logger.info("All Parameter values have been collected successfully")

    # Your code goes here.
    return final_out, params_logs  # returns the secret as dictionary
